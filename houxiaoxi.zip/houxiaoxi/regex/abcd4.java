package com.houxiaoxi.regex;

import java.util.regex.Pattern;

public class abcd4 {

	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("^[a-zA-Z]//w{5,17}$");


	}

}
