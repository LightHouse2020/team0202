/*
 * Copyright (C) 2013～2023
 * Yfann Software Technology (Shanghai) Co.，LTD
 * All Rights Reserved.
*/

package com.itedu.season09_wangjing.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class IteduDispatcherServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String urlStr = request.getRequestURI();
		if ("/season09_wangjing/home".equals(urlStr)) {
			// TODO 处理
			request.getRequestDispatcher("/WEB-INF/jsp/home.jsp").forward(request, response);
		}else if ("/season09_wangjing/login".equals(urlStr)) {
			// TODO 处理
			request.getRequestDispatcher("/WEB-INF/jsp/XXX.jsp").forward(request, response);
		}

		else if ("".equals(urlStr)) {
			request.getRequestDispatcher("/WEB-INF/jsp/XXX.jsp").forward(request, response);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String urlStr = request.getRequestURI();
		if ("/season09_wangjing/user".equals(urlStr)) {
			// TODO 处理
			request.getRequestDispatcher("/WEB-INF/jsp/user.jsp").forward(request, response);

		} else if ("".equals(urlStr)) {
			request.getRequestDispatcher("/WEB-INF/jsp/XXX.jsp").forward(request, response);
		}

	}

}
