package com.hankunzuye.regex;

import java.util.regex.Pattern;

public class zuoye4 {

	public static void main(String[] args) {
		Pattern.compile("^[a-zA-Z]//w{6,18}$");

	}

}
