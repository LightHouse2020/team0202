package com.hankunzuye.regex;

import java.util.regex.Pattern;

public class zuoye2 {

	public static void main(String[] args) {
		Pattern.compile("^//d{n}$");
		
				

	}

}
