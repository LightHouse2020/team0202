package com.hankunzuye.regex;

import java.util.regex.Pattern;

public class Demo {

	public static void main(String[] args) {
		 Pattern.compile("^[0-9]*$");
		
	}

}
